# helpdesk
Springboot app using gradle. It has a session management technique implemented through cookies. Authentication happens against a table in MySQL database.
